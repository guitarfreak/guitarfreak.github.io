
Playlist Viewer.

Download and view Youtube playlists.

Runs on Windows x86/x64 starting with Windows XP.
Requires Opengl 4.5.